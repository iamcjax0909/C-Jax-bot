module.exports = {
    commands: ["pulse", "memory", "uptime", "latency", "status"],

    async execute(sock, msg) {
        const jid = msg.key.remoteJid
        const cmd = msg.message.conversation.split(" ")[0].slice(1)

        if (cmd === "pulse") {
            await sock.sendMessage(jid, { text: "🩸 C-JAX Core Online." })
        }

        if (cmd === "memory") {
            const used = process.memoryUsage().heapUsed / 1024 / 1024
            await sock.sendMessage(jid, { text: `🧠 Memory: ${used.toFixed(2)} MB` })
        }

        if (cmd === "uptime") {
            const seconds = process.uptime()
            await sock.sendMessage(jid, { text: `⏳ Uptime: ${Math.floor(seconds)}s` })
        }

        if (cmd === "latency") {
            const start = Date.now()
            await sock.sendMessage(jid, { text: "Testing..." })
            const end = Date.now()
            await sock.sendMessage(jid, { text: `⚡ ${end - start} ms` })
        }

        if (cmd === "status") {
            await sock.sendMessage(jid, { text: "⚙️ All systems operational." })
        }
    }
}
