module.exports = {
    commands: ["reboot", "broadcast"],

    async execute(sock, msg, args) {
        const jid = msg.key.remoteJid
        const cmd = msg.message.conversation.split(" ")[0].slice(1)

        if (cmd === "reboot") {
            await sock.sendMessage(jid, { text: "♻️ Restarting..." })
            process.exit(1)
        }

        if (cmd === "broadcast") {
            const text = args.join(" ")
            if (!text) return sock.sendMessage(jid, { text: "Provide message." })
            await sock.sendMessage(jid, { text: `📡 Broadcast:\n\n${text}` })
        }
    }
}
