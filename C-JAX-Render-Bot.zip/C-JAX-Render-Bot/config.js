module.exports = {
    ownerNumber: "2347076849343@s.whatsapp.net",
    phoneNumber: "2347076849343",
    prefix: ".",
    botName: "C-JAX MD-Bot"
}
