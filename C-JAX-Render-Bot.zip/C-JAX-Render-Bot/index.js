const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion
} = require("@whiskeysockets/baileys")

const P = require("pino")
const fs = require("fs")
const config = require("./config")

async function startBot() {

    const { state, saveCreds } = await useMultiFileAuthState("./sessions")
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
        version,
        auth: state,
        logger: P({ level: "silent" }),
        browser: ["C-JAX MD-Bot", "Chrome", "1.0"],
        markOnlineOnConnect: true,
        syncFullHistory: false
    })

    sock.ev.on("creds.update", saveCreds)

    sock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect } = update

        if (connection === "open") {
            console.log("🩸 CONNECTED SUCCESSFULLY ON RENDER")
        }

        if (connection === "close") {
            const reason = lastDisconnect?.error?.output?.statusCode
            console.log("Connection closed. Code:", reason)

            if (reason !== DisconnectReason.loggedOut) {
                console.log("Reconnecting...")
                startBot()
            }
        }
    })

    // Pairing Code Mode
    if (!state.creds.registered) {
        setTimeout(async () => {
            try {
                const code = await sock.requestPairingCode(config.phoneNumber)
                console.log("\nENTER THIS PAIRING CODE ON WHATSAPP:\n")
                console.log(code)
                console.log("\n")
            } catch (err) {
                console.log("Pairing error:", err)
            }
        }, 8000)
    }

    sock.ev.on("messages.upsert", async ({ messages }) => {
        const msg = messages[0]
        if (!msg.message) return

        const sender = msg.key.remoteJid
        const text =
            msg.message.conversation ||
            msg.message.extendedTextMessage?.text

        if (!text) return
        if (!text.startsWith(config.prefix)) return
        if (sender !== config.ownerNumber) return

        const args = text.slice(1).trim().split(" ")
        const command = args.shift().toLowerCase()

        const commandFiles = fs.readdirSync("./commands")

        for (let file of commandFiles) {
            delete require.cache[require.resolve(`./commands/${file}`)]
            const cmd = require(`./commands/${file}`)

            if (cmd.commands.includes(command)) {
                try {
                    await cmd.execute(sock, msg, args)
                } catch (err) {
                    console.log("Command error:", err)
                }
            }
        }
    })
}

startBot()
